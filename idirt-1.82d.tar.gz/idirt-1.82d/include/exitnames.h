#ifndef _EXITNAMES_H
#define _EXITNAMES_H

char *Exits[] = {"North", "East",
	         "South", "West",
		 "Up",    "Down",
	          TABLE_END
	        };

char *exits[] = {"north", "east",
	         "south", "west",
		 "up",    "down",
	          TABLE_END
	        };

#endif
