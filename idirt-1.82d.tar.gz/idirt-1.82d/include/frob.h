#ifndef _FROB_H
#define _FROB_H

void	frobcom(char *line);

#endif
