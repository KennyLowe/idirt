#ifndef _MOVE_H
#define _MOVE_H

int	dodirn(int vb);
int	dogocom(void);

#endif
