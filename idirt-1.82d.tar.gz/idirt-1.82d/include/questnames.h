#ifndef _QUESTNAMES_H
#define _QUESTNAMES_H

/*
 * Quest names
 */
char *Quests[] = {
	"ElvenForest",	"SorcerorsTower",	"FindExcalibur",
	"FindGrail",	"FieryKingsHall",	"Mana",
	"SunDisc",	"Talon",		"Mithdan",
	TABLE_END
};

#endif
