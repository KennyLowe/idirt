#ifndef _PUFF_H
#define _PUFF_H

int	randplr(void);
void	puffcom(int mon);

#endif
