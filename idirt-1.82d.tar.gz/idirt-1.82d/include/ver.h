#ifndef _VER_H
#define _VER_H

void	versioncom (void);
int	linknumber (void);

#endif
