#ifndef _VIEWCOM_H
#define _VIEWCOM_H

void	viewcom(void);

#endif
