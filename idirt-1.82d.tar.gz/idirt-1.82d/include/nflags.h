#ifndef _NFLAGS_H
#define _NFLAGS_H

/* Language Flags (NFLAGS) */

#define NFL_ENGLISH	0
#define NFL_XARA	1
#define NFL_HYEEL	2
#define NFL_DRAKEN	3
#define NFL_RAVASHEM	4
#define NFL_SORCA	5
#define NFL_ALOUTH	6
#define NFL_XIZART	7
#define NFL_RAMAR	8
#define	NFL_JOHANI	9

#endif
