#ifndef _ACTIONS_H
#define _ACTIONS_H

int	boot_extern(FILE *f, char *fname);
int	fextern(char *verb);
int	lisextern(void);
void	flowercom(void);
void	ticklecom(void);
void	petcom(void);
void	praycom(void);
void	wavecom(void);
void	rosecom(void);
void	wipecom(void);
void	meditatecom(void);

#endif
