#ifndef _IFLAGNAMES_H
#define _IFLAGNAMES_H

char *Iflags[] = {
    "FireballSpell",    "MissileSpell", "FrostSpell",   "ShockSpell",
    "AidSpell",         "VTouchSpell",  "LightSpell",   "DamageSpell",
    "ArmorSpell",       "BHandsSpell",  "BlurSpell",    "IStormSpell",
    TABLE_END
};

#endif
