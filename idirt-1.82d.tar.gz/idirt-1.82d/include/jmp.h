#ifndef _JMP_H
#define _JMP_H

#define JMP_QUITTING 1

#endif
