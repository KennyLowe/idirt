#ifndef _ACCT_H
#define _ACCT_H

void	acctcom(void);
int	dopc(int max, int exist);
void	countmobiles(int zone);
void	countobjects(int zone);
void	countrooms(int zone);
void	objectscom(void);
void	mstatcom(void);
void    usercom(void);
void    whocom(Boolean do_name);
void    mwhocom(void);
void    mobilecom(void);
void	showplayer(void);
void	mobilecom(void);

#endif
