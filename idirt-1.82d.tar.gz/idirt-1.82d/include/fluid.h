#ifndef _FLUID_H
#define _FLUID_H

/* People invisible on the Wizlist */
char *InvisList[] = {
	"Oracle",	"Tycoon",	TABLE_END
};

/* People listed as 'fluid' on the Wizlist */
char *FluidList[] = {
	TABLE_END
};

#endif
