#ifndef _NFLAGNAMES_H
#define _NFLAGNAMES_H

char *Nflags[] = {
        "English",      "Xara",         "Hyeel",        "Draken",
        "Ravashem",     "Sorca",        "Alouth",       "Xizart",
	"Ramar",	"Johani",	TABLE_END
};
 
#endif
