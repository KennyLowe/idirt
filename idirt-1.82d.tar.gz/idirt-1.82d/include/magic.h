#ifndef _MAGIC_H
#define _MAGIC_H

void	healcom(void);
void	healallcom(void);
void	forcecom(void);
void	forceallcom(void);
void	sumcom(void);
void	viscom(void);
void	inviscom(void);
void	resurcom(void);
void	deafcom(void);
void	blindcom(void);
void	dumbcom(void);
void	cripplecom(void);
void	curecom(void);

#endif
