#ifndef _EFLAGNAMES_H
#define _EFLAGNAMES_H

char *Eflags[] = {
	"Fireball",	"FearFireball",	"ImmFireball",	"Missile",
	"FearMissile",	"ImmMissile",	"Frost",	"FearFrost",
	"ImmFrost",	"Shock",	"FearShock",	"ImmShock",
	"Aid",		"VTouch",	"ImmVTouch",	"Light",
	"Damage",	"Armor",	"BHands",	"FearBHands",
	"ImmBHands",	"Blur",		"IceStorm",	"FearIceStorm",
	"ImmIceStorm",	TABLE_END
};

#endif
