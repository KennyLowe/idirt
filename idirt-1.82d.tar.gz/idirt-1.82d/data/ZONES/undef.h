#undef sun  /* it messed up some room-descs... "sunshine" -> "1shine" etc.. */
